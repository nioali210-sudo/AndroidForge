# TapLink NFC — proyek sumber Android

Tautan bawaan: https://www.instagram.com/nioali_muhammad/

## Fungsi
Proyek ini mencoba mengemulasikan NFC Forum Type 4 NDEF tag melalui Android Host Card Emulation (HCE), berisi satu record URI Instagram.

## Cara membangun APK
1. Buka proyek ini dengan Android Studio versi yang mendukung Android Gradle Plugin 8.7.3.
2. Tunggu Gradle selesai sinkronisasi.
3. Pilih **Build > Build APK(s)**.
4. APK debug biasanya dibuat di `app/build/outputs/apk/debug/app-debug.apk`.
5. Instal APK di HP yang memiliki NFC dan dukungan HCE.

## Cara mencoba
1. Aktifkan NFC pada HP pengirim dan biarkan layar menyala serta HP tidak terkunci.
2. Jalankan TapLink NFC sekali, lalu dekatkan bagian belakang HP pengirim ke area NFC HP Android penerima.
3. Keberhasilan tidak dijamin: pembaca NFC bawaan di beberapa HP mungkin tidak memproses HCE/NDEF dari HP lain seperti kartu NFC fisik. Perlu diuji pada kedua model HP.

## Batasan
- Ini adalah kode sumber proyek, bukan APK yang sudah dikompilasi atau diuji di OPPO A57.
- HCE hanya bekerja bila perangkat/firmware mendukungnya.
- Tidak semua HP Android akan otomatis menampilkan tautan saat dua HP ditempelkan.
