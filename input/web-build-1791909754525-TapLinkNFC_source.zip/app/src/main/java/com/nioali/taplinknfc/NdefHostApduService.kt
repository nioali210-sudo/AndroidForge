package com.nioali.taplinknfc

import android.nfc.cardemulation.HostApduService
import android.os.Bundle
import java.io.ByteArrayOutputStream

class NdefHostApduService : HostApduService() {
    companion object {
        private val AID = hex("D2760000850101")
        private val CC_FILE = hex("E103")
        private val NDEF_FILE = hex("E104")
        private val SW_OK = hex("9000")
        private val SW_NOT_FOUND = hex("6A82")
        private val SW_BAD = hex("6A82")

        private fun hex(s: String) = s.chunked(2).map { it.toInt(16).toByte() }.toByteArray()

        private fun ndefUriRecord(): ByteArray {
            val url = "https://www.instagram.com/nioali_muhammad/"
            val prefix = "https://"
            val payload = byteArrayOf(0x04) + url.removePrefix(prefix).toByteArray(Charsets.UTF_8)
            val out = ByteArrayOutputStream()
            out.write(0xD1) // MB, ME, SR, TNF well-known
            out.write(0x01) // type length
            out.write(payload.size)
            out.write(0x55) // URI record type 'U'
            out.write(payload)
            return out.toByteArray()
        }

        private val cc = hex("000F20003B00340406E10400FF")
        private val ndefFile: ByteArray by lazy {
            val record = ndefUriRecord()
            byteArrayOf((record.size shr 8).toByte(), record.size.toByte()) + record
        }
    }

    private var selectedFile: ByteArray? = null

    override fun processCommandApdu(commandApdu: ByteArray, extras: Bundle?): ByteArray {
        if (commandApdu.size < 4) return SW_BAD

        // SELECT by AID: 00 A4 04 00 Lc [AID]
        if (commandApdu[0] == 0x00.toByte() &&
            commandApdu[1] == 0xA4.toByte() &&
            commandApdu[2] == 0x04.toByte()) {
            val lc = commandApdu.getOrNull(4)?.toInt()?.and(0xFF) ?: 0
            val selectedAid = if (commandApdu.size >= 5 + lc) commandApdu.copyOfRange(5, 5 + lc) else byteArrayOf()
            return if (selectedAid.contentEquals(AID)) SW_OK else SW_NOT_FOUND
        }

        // SELECT file identifier: 00 A4 00 0C 02 E1 03 / E1 04
        if (commandApdu[0] == 0x00.toByte() &&
            commandApdu[1] == 0xA4.toByte() &&
            commandApdu.size >= 7) {
            val fileId = commandApdu.copyOfRange(commandApdu.size - 2, commandApdu.size)
            selectedFile = when {
                fileId.contentEquals(CC_FILE) -> cc
                fileId.contentEquals(NDEF_FILE) -> ndefFile
                else -> null
            }
            return if (selectedFile != null) SW_OK else SW_NOT_FOUND
        }

        // READ BINARY: 00 B0 offsetHi offsetLo Le
        if (commandApdu[0] == 0x00.toByte() && commandApdu[1] == 0xB0.toByte() && commandApdu.size >= 5) {
            val file = selectedFile ?: return SW_NOT_FOUND
            val offset = ((commandApdu[2].toInt() and 0xFF) shl 8) or (commandApdu[3].toInt() and 0xFF)
            val leRaw = commandApdu[4].toInt() and 0xFF
            val le = if (leRaw == 0) 256 else leRaw
            if (offset >= file.size) return SW_OK
            val end = minOf(file.size, offset + le)
            return file.copyOfRange(offset, end) + SW_OK
        }
        return SW_BAD
    }

    override fun onDeactivated(reason: Int) {
        selectedFile = null
    }
}
