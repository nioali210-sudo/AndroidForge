package com.nioali.taplinknfc

import android.app.Activity
import android.nfc.NfcAdapter
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val nfc = NfcAdapter.getDefaultAdapter(this)
        val supported = nfc != null
        val enabled = nfc?.isEnabled == true
        val hce = packageManager.hasSystemFeature("android.hardware.nfc.hce")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
        }

        fun addLine(text: String, size: Float = 18f) {
            root.addView(TextView(this).apply {
                this.text = text
                textSize = size
                gravity = Gravity.CENTER
                setPadding(0, 10, 0, 10)
            })
        }

        addLine("TapLink NFC", 28f)
        addLine("Tautan Instagram yang disimpan:")
        addLine("https://www.instagram.com/nioali_muhammad/", 16f)
        addLine("NFC tersedia: " + if (supported) "Ya" else "Tidak")
        addLine("NFC aktif: " + if (enabled) "Ya" else "Tidak")
        addLine("HCE tersedia: " + if (hce) "Ya" else "Tidak")
        addLine("Coba buka kunci layar, aktifkan NFC, lalu dekatkan bagian belakang HP ini ke area NFC HP Android penerima.")
        addLine("Catatan: pembacaan tautan antar-HP tidak dijamin pada semua model.", 14f)
        setContentView(root)
    }
}
